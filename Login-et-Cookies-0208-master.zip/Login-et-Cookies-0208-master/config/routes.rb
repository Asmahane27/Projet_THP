Rails.application.routes.draw do
  get 'sessions/new'
  root to: 'static_pages#home'

  get    '/login',   to: 'sessions#new'
  post   '/login',   to: 'sessions#create'
  delete '/logout',  to: 'sessions#destroy'
  get     '/secretdef', to: 'sessions#secret', as: 'chuuuut'
  resources :users 
end
# For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html