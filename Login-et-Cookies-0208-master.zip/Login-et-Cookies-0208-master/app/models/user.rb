class User < ApplicationRecord
  # permet de standardiser l'enregistrement des emails par downcase
  before_save { self.email = email.downcase }

  # nom nil et +50 = faux
  validates :name,  presence: true, length: { maximum: 50 }

  # Constante initiale qui authorise les doubles points ds email
  # VALID_EMAIL_REGEX = /\A[\w+\-.]+@[a-z\d\-.]+\.[a-z]+\z/i

  # Constante modifiée pour interdire les doubles points ds email
    VALID_EMAIL_REGEX = /\A[\w+\-.]+@[a-z\d\-]+(\.[a-z\d\-]+)*\.[a-z]+\z/i
   # email nil et +255 = faux, regex, email unique
  validates :email, presence: true, length: { maximum: 255 },
                    format: { with: VALID_EMAIL_REGEX },
                    uniqueness: { case_sensitive: false }

  has_secure_password
  
  validates :password, presence: true, length: { minimum: 6 }

  # Returns the hash digest of the given string.
  def User.digest(string)
    cost = ActiveModel::SecurePassword.min_cost ? BCrypt::Engine::MIN_COST :
                                                  BCrypt::Engine.cost
    BCrypt::Password.create(string, cost: cost)
  end
end
