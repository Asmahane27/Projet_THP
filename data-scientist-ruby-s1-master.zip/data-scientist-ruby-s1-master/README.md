Ce peer-programming de Ruby Basics (journalist.rb & crypto.rb) vous est présenté par Dimitri KIAVU et Pierre Tâm-Anh LE KHAC.


