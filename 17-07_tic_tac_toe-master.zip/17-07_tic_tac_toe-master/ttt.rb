  

class Game
#########################################################
attr_accessor :board

 def initialize
    #TO DO :
    #Quand la classe s'initialize, elle doit créer 9 instances BoardCases
    #Ces instances sont rangées dans une array qui est l'attr_accessor de la classe
    @case_0 = " "
    @case_1 = " "
    @case_2 = " "
    @case_3 = " "
    @case_4 = " "
    @case_5 = " "
    @case_6 = " "
    @case_7 = " "
    @case_8 = " "
   	 
   	@board = [@case_0, @case_1, @case_2, @case_3, @case_4, @case_5, @case_6, @case_7, @case_8 ]
  end

  def print_the_tab
  #TO DO : afficher le plateau
    puts " #{@board[0]}    | #{@board[1]}    | #{@board[2]} "
    puts "----------------"
    puts " #{@board[3]}    | #{@board[4]}    | #{@board[5]} "
    puts "----------------"
    puts " #{@board[6]}    | #{@board[7]}    | #{@board[8]} "
  end
# Welcoming==>OK
  
  def deb
  puts "****************************************************************" 
  puts ".....Comme-si-t'avais-pas-SUFFISAMMENT-joué-au-morpion-hier....."
  puts "****************************************************************"  
  nom_player
  end

########################################################
# Définition du nom des joueurs==>OK
  def nom_player 
 	  puts "Quel est ton nom?"
    #STDOUT.flush
    @user_name_1 = gets.chomp.capitalize
    puts
  	puts "Bienvenu #{@user_name_1}!!" 
  	puts "............................................................................................."
  	puts 
  	puts "Ok, quel est ton nom, autre toi? (Genre, vous n'etes plusieurs dans ta tête!)"  
    @user_name_2 = gets.chomp.capitalize
    puts
  	puts "Bienvenu #{@user_name_2}!!Ravie que tu puisses enfin t'exprimer!"   
  	puts "............................................................................................." 
  	puts
  	puts
  	puts
  	puts
  	
  symbole_pr_user
  end


#########################################################
#Définition du symbole par joueur==>OK
def symbole_pr_user
  puts "Alors, au pif: "
  @user_1 = rand() > 0.5 ? 'X' : 'O' # formule permettant de bénéficier des joies de l'aléatoire
  @user_2 = @user_1 == 'X' ? 'O' : 'X' # si le result en haut est X, de fait, user_2 aura l'autre symbole
  puts "#{@user_name_1} ton symbole sera  #{@user_1}, et donc #{@user_name_2} tu auras le symbole  #{@user_2}!"
  puts "............................................................................................." 
  puts 
qui_qui_commence
end	

def qui_qui_commence
	if(@user_1 == 'X')
		puts
		puts
   		puts "Toujours au pif: #{@user_name_1} c'est toi qui commence!!#{@user_name_2}, n'aies pas le seum, c'est aléatoire"
   		puts ".................................................................................................."
   		puts
    	user_1_turn
    else
      	puts "Toujours au pif: #{@user_name_2} c'est toi qui commence!!#{@user_name_1}, n'aies pas le seum, c'est aléatoire"
      	puts "..................................................................................................."
      	puts
      	user_2_turn
    end  
 end

 def user_1_turn
 puts
 puts
 puts " #{@user_name_1} choisis un numéro entre 1 et 9 pour placer ton symbole "
 choice_user_1 = gets.chomp.to_i 
    
	if @board[choice_user_1 -1] == " "
    	@board[choice_user_1 -1] = @user_1
    	@board << @user_1
    	print_the_tab
    	#victory?
    	check_game(@user_2)
	else 
		pas_concentré_e_1
	end
  end
	
  
  def user_2_turn
  puts " #{@user_name_2} choisis un numéro entre 1 et 9 pour placer ton symbole "
  choice_user_2 = gets.chomp.to_i 
    
	if @board[choice_user_2 -1] == " "
    	@board[choice_user_2 -1] = @user_2
    	@board << @user_2
    	print_the_tab
    	#victory?
    	check_game(@user_1)
	else 
		pas_concentré_e_2
	end
  end

  def pas_concentré_e_1
  	puts "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  	puts "Azy, concentre-toi là #{@user_name_1}!! Déjà que c'est long les corrections!:o)"
  	puts "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  	print_the_tab		
 	user_1_turn
  end

  def pas_concentré_e_2
  	puts "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  	puts "Azy, concentre-toi là #{@user_name_2}!! Déjà que c'est long les corrections!:o)"
  	puts "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  	print_the_tab		
 	user_2_turn
  end

  

  def check_game(next_user)
  	game_over = false
  	if 
  	@board[0] == @board[1] && @board[0] == @board[2] && @board[0] == @user_1||
  	@board[3] == @board[4] && @board[3] == @board[5] && @board[3] == @user_1||
  	@board[6] == @board[7] && @board[6] == @board[8] && @board[6] == @user_1||
  	@board[0] == @board[3] && @board[0] == @board[6] && @board[0] == @user_1||
  	@board[1] == @board[4] && @board[1] == @board[7] && @board[1] == @user_1||
  	@board[2] == @board[5] && @board[2] == @board[8] && @board[2] == @user_1||
  	@board[0] == @board[4] && @board[0] == @board[8] && @board[0] == @user_1||
  	@board[2] == @board[4] && @board[2] == @board[6] && @board[2] == @user_1
    puts "Bravo #{@user_name_1}, TU AS GAGNE!!!"
    game_over = true
    end

    if 
  	@board[0] == @board[1] && @board[0] == @board[2] && @board[0] == @user_2||
  	@board[3] == @board[4] && @board[3] == @board[5] && @board[3] == @user_2||
  	@board[6] == @board[7] && @board[6] == @board[8] && @board[6] == @user_2||
  	@board[0] == @board[3] && @board[0] == @board[6] && @board[0] == @user_2||
  	@board[1] == @board[4] && @board[1] == @board[7] && @board[1] == @user_2||
  	@board[2] == @board[5] && @board[2] == @board[8] && @board[2] == @user_2||
  	@board[0] == @board[4] && @board[0] == @board[8] && @board[0] == @user_2||
  	@board[2] == @board[4] && @board[2] == @board[6] && @board[2] == @user_2
    puts "Bravo #{@user_name_2}, TU AS GAGNE!!!"
    game_over = true
    end

  	unless game_over
  		if (mouvement > 0)
  			if(next_user == @user_1)
	        user_1_turn
	      	else
	        user_2_turn
	      	end
		else
		puts "Bah, personne n'a gagné, ton combat avec toi-meme a été epique, BRAVO!!"
		end
	end
end

 def mouvement
 	case_vide = 0
 	
 	@board.each do |case_test|
 		if case_test == " "
 			case_vide +=1
 		end
 	end
 	case_vide
 end

end


Game.new.deb