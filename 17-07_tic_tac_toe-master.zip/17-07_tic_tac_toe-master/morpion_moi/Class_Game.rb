class Game
#########################################################
# Welcoming==>OK
def begining
  puts "...........**********************************............" 
  puts "Comme si t'avais pas suffisamment joué au morpion hier..."
  puts "...........**********************************............" 
  end

########################################################
# Définition du nom des joueurs==>OK
 def initialize 
 	  puts "Quel est ton nom?"
    #STDOUT.flush
    @user_name_1 = gets.chomp
  puts "Bienvenu #{@user_name_1}!!" 
  puts "............................................................................................." 
  puts "Ok, et partant du principe que vous êtes plusieurs dans ta tête, quel est ton nom, autre toi?"  
    @user_name_2 = gets.chomp
  puts "Bienvenu #{@user_name_2}!!Ravie que tu puisses enfin t'exprimer!"   
  puts "............................................................................................." 
end

def rules
    puts
    puts"===================================="
    puts "=======> Pour faire simple <======="
    puts 
    puts "Voici les numéros qu'il faudra indiquer "
    puts "pour placer tes pions :"
    puts
    puts "  1 | 2 | 3 "
    puts "-------------"
    puts "  4 | 5 | 6 "
    puts "-------------"
    puts "  7 | 8 | 9 "
    puts
    puts "====================================="
    puts "Aligne trois symboles similaires, et prouve que t'es un.e champion.ne du monde!!"
    puts
    puts "====================================="
    puts
#########################################################
#Définition du symbole par joueur==>OK
def symbole_pr_user
  puts "Justement, parlons de symbole...Au pif: "
  @user_1 = rand() > 0.5 ? 'X' : 'O' # formule permettant de bénéficier des joies de l'aléatoire
  @user_2 = @user_1 == 'X' ? 'O' : 'X' # si le result en haut est X, de fait, user_2 aura l'autre symbole
  puts "#{@user_name_1} ton symbole sera  #{@user_1}, et donc #{@user_name_2}, tu auras ce symbole  #{@user_2}" 
end	

def qui_qui_commence
if(@user_1 == 'X')
      puts "#{user_name_1} c'est toi qui commence!!#{@user_name_2}, n'aies pas le seum, c'est aléatoire"
      user_1_turn
    else
      puts "#{user_name_2} c'est toi qui commence!!#{@user_name_1}, n'aies pas le seum, c'est aléatoire"
      user_2_turn
    end  
end

end