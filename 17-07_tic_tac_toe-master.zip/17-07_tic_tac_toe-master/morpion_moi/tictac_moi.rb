class Game
#########################################################
# Welcoming==>OK
def begining
  puts "...........**********************************............" 
  puts "Comme si t'avais pas suffisamment joué au morpion hier..."
  puts "...........**********************************............" 
  end

########################################################
# Définition du nom des joueurs==>OK
 def initialize 
 	  puts "Quel est ton nom?"
    #STDOUT.flush
    @user_name_1 = gets.chomp.capitalize
  puts "Bienvenu #{@user_name_1}!!" 
  puts "............................................................................................." 
  puts "Ok, et partant du principe que vous êtes plusieurs dans ta tête, quel est ton nom, autre toi?"  
    @user_name_2 = gets.chomp.capitalize
  puts "Bienvenu #{@user_name_2}!!Ravie que tu puisses enfin t'exprimer!"   
  puts "............................................................................................." 
end

def rules
    puts
    puts"===================================="
    puts "=======> Pour faire simple <======="
    puts 
    puts "Voici les numéros qu'il faudra indiquer "
    puts "pour placer tes pions :"
    puts
    puts "  1 | 2 | 3 "
    puts "-------------"
    puts "  4 | 5 | 6 "
    puts "-------------"
    puts "  7 | 8 | 9 "
    puts
    puts "====================================="
    puts "Aligne trois symboles similaires, et prouve que t'es un.e champion.ne du monde!!"
    puts
    puts "====================================="
    puts
#########################################################
#Définition du symbole par joueur==>OK
def symbole_pr_user
  puts "Justement, parlons de symbole...Au pif: "
  @user_1 = rand() > 0.5 ? 'X' : 'O' # formule permettant de bénéficier des joies de l'aléatoire
  @user_2 = @user_1 == 'X' ? 'O' : 'X' # si le result en haut est X, de fait, user_2 aura l'autre symbole
  puts "#{@user_name_1} ton symbole sera  #{@user_1}, et donc #{@user_name_2}, tu auras ce symbole  #{@user_2}" 
end	

def qui_qui_commence
if(@user_1 == 'X')
      puts "#{user_name_1} c'est toi qui commence!!#{@user_name_2}, n'aies pas le seum, c'est aléatoire"
      user_1_turn
    else
      puts "#{user_name_2} c'est toi qui commence!!#{@user_name_1}, n'aies pas le seum, c'est aléatoire"
      user_2_turn
    end  
 end
end


########################################################"
# class Board
#   include Enumerable
  #TO DO : la classe a 1 attr_accessor, une array qui contient les BoardCases



  def test_2_initialize
    #TO DO :
    #Quand la classe s'initialize, elle doit créer 9 instances BoardCases
    #Ces instances sont rangées dans une array qui est l'attr_accessor de la classe
#####################################################
    
    @board = [" ", " "," ",
      " ", " ", " ",
      " "," ", " "]

# Rappel de chacune des valeurs via leur index: pour initialiser à chaque tour    
    
  end
test_2_initialize

def aff_tab
    puts " #{@board[0]}    | #{@board[1]}    | #{@board[2]} "
    puts "----------------"
    puts " #{@board[3]}    | #{@board[4]}    | #{@board[5]} "
    puts "----------------"
    puts " #{@board[6]}    | #{@board[7]}    | #{@board[8]} "
  end
#########################################################################
#OK manque les if pour conditionner les champs (mvs num) + case deja prise + le win
 def play
    #TO DO : une méthode qui change la BoardCase jouée en fonction de la valeur du joueur (X, ou O)
    i= 0
    while i < 9
    puts " #{@user_name_1} choisis un numéro entre 1 et 9 pour placer ton symbole "
    choice_user_1 = gets.chomp.to_i 
    
    if @board[choice_user_1 -1] == " "
    @board[choice_user_1 -1] = @user_1
    @board << @user_1
    aff_tab
    #else puts "mvse entrée change"
    i +=1
    

    puts " #{@user_name_2} choisis un numéro entre 1 et 9 pour placer ton symbole "
    choice_user_2 = gets.chomp.to_i 
    
    if @board[choice_user_2 -1] == " "
    @board[choice_user_2 -1] = @user_2
    @board << @user_2
    aff_tab
    #else puts "mvse entrée change"
    i +=1
      
  end
  end
  if i = 9 
    puts "match nul"
  end
end
end
    #Quand la classe s'initialize, elle doit créer 9 instances BoardCases
    #Ces instances sont rangées dans une array qui est l'attr_accessor de la classe

play
##########################################################
def victory?
  #TO DO : qui gagne ?
  if  @board[0] = @board[1] = @board[2] = @user_1 ||
      @board[3] = @board[4] = @board[5] = @user_1 ||
      @board[6] = @board[7] = @board[8] = @user_1 ||
      @board[0] = @board[3] = @board[6] = @user_1 ||
      @board[1] = @board[4] = @board[7] = @user_1 ||
      @board[2] = @board[5] = @board[8] = @user_1 ||
      @board[0] = @board[4] = @board[8] = @user_1 ||
      @board[2] = @board[4] = @board[6] = @user_1 
      
      puts "Bravo #{@user_name_1}, TU AS GAGNE!!!"
  elsif 
      @board[0] = @board[1] = @board[2] = @user_2 ||
      @board[3] = @board[4] = @board[5] = @user_2 ||
      @board[6] = @board[7] = @board[8] = @user_2 ||
      @board[0] = @board[3] = @board[6] = @user_2 ||
      @board[1] = @board[4] = @board[7] = @user_2 ||
      @board[2] = @board[5] = @board[8] = @user_2 ||
      @board[0] = @board[4] = @board[8] = @user_2 ||
      @board[2] = @board[4] = @board[6] = @user_2 
      
      puts "Bravo #{@user_name_2}, TU AS GAGNE!!!"
 
  # else  
  #     @board[0] = @board[1] = @board[2] 
  #     = @board[3] = @board[4=  @board[5] 
  #     = @board[6]= @board[7] = @board[8] != " "
  #     puts "match nul"    
  end

end

def scenarii_win
  scenario_1 = @board[0] = @board[1] = @board[2] 
  scenario_2 = @board[3] = @board[4] = @board[5] 
  scenario_3 = @board[6] = @board[7] = @board[8] 
  scenario_4 = @board[0] = @board[3] = @board[6] 
  scenario_5 = @board[1] = @board[4] = @board[7] 
  scenario_6 = @board[2] = @board[5] = @board[8] 
  scenario_7 = @board[0] = @board[4] = @board[8] 
  scenario_8 = @board[2] = @board[4] = @board[6] 
end
# def match_nul
  
#   if @board[0] && @board[1] && @board[2] && @board[3] && @board[4] && @board[5] && @board[6] && @board[7] && @board[8]
#    != " "