#! /usr/bin/env ruby

require 'nokogiri'
require 'open-uri'
require 'rubygems' # =test 2: a mettre en plus selon le tuto:http://ruby.bastardsbook.com/chapters/html-parsing/
require 'restclient'
require 'active_support/time'
#################################################
# 1. Route de la mairie
#################################################
# Récupérer les url déjà =expl de base méthode xpath

doc = Nokogiri::HTML(open("http://annuaire-des-mairies.com/val-d-oise.html"))
	puts doc.xpath('//a[@class = "lientxt"]/@href')
######################################################################################
# Tout d'abord, écris une méthode get_the_email_of_a_townhal_from_its_webpage qui, 
# comme son nom l'indique, récupère l'adresse email à partir de l'url d'une mairie, 
# par exemple celle de Vauréal

def get_the_email_of_a_townhal_from_its_webpage
    doc = Nokogiri::HTML(open("http://annuaire-des-mairies.com/91/dourdan.html"))
# Possibilité 1    
    puts doc.css('td')[7].text
# =>result:elus@mairie-dourdan.fr 

# Possibilité 2
    puts doc.xpath('/html/body/div/main/section[2]/div/table/tbody/tr[4]/td[2]').text
# =>result:elus@mairie-dourdan.fr

# Possibilité 3
    puts doc.xpath("//td").select { |lestd| lestd.text if lestd.text.include?("@")}
# =>result:<td>elus@mairie-dourdan.fr</td>
 end
puts get_the_email_of_a_townhal_from_its_webpage

=begin

##############################################################
# Ensuite, écris une méthode get_all_the_urls_of_val_doise_townhalls qui, 
# comme son nom l'indique, récupère toutes les url de villes du Val d'Oise. 
# C'est recommandé de le faire de cette page web

# (A noter, soit on utilise Nokigri langage, soit on utilise Xpath, mais les deux langages sont incompatible)
#Méthode ==>NOKIGIRI OK

array_des_sites = []

def get_all_the_urls_of_val_doise_townhalls(array)
   	doc = Nokogiri::HTML(open("http://annuaire-des-mairies.com/val-d-oise.html"))
                 
            doc.css('a[class = lientxt]').each do |link| 		#methode noko et non xpath
               	lien = link['href'] 							#nomme chacun des liens récupérés, cela permet de les rappeler dans string
                lien[0]= ''										#efface les './' de chacun des liens
                url = "http://annuaire-des-mairies.com#{lien}"	#concate des url
                array << url 									#insere les url dans un tableau
        	end
end

get_all_the_urls_of_val_doise_townhalls(array_des_sites)
# result: "http://annuaire-des-mairies.com/95/wy-dit-joli-village.html"

# Une fois que les liens sont créés, récupération des emails
def concat_des_deux (array)
	array.each do |i|
		doc = Nokogiri::HTML(open(i))							#chemin pour chacune des mairie	dans mon nv tab array					
		puts doc.css('td')[7].text								# chemin pour le mail
	end
end

concat_des_deux(array_des_sites)

# result: ville-viarmes@wanadoo.fr

#################################################
#BONUS
def get_all_the_urls_of_val_doise_townhalls
my_super_name_of_town = []
my_super_emails = []

	doc = Nokogiri::HTML(open("http://annuaire-des-mairies.com/val-d-oise.html"))
	link_to_check = doc.xpath('//a[@class = "lientxt"]/@href')
	#ça me donne tous les a, qui sont les noms de villes et url de ville
	#indiquer de rentrer dans chaque url de ville ?????????
	link_to_check.each do |one_link|
		# i_need_to_check_page(one_link)
		doc = Nokogiri::HTML(open("http://annuaire-des-mairies.com/#{one_link}"))
		my_super_name_of_town = doc.xpath('/html/body/div/main/section[1]/div/div/div/h1')
		#cette ligne me recupère les noms de ville
		my_super_emails = doc.xpath('/html/body/div/main/section[2]/div/table/tbody/tr[4]/td[2]')
		#cette ligne me récupere les emails
		my_super_hash = my_super_name_of_town.zip(my_super_emails)
		puts my_super_hash
	end
end

p get_all_the_urls_of_val_doise_townhalls
=end

############################################################################
#2. Trader de l'obscur
############################################################################
# ARRAY DE HASH CRIPTO
# CA MARCHE PUTAIN  
def creat_my_hash          
	array_crypto_name = []
	array_crypto_price = []
	page = Nokogiri::HTML(open("https://coinmarketcap.com/all/views/all/"))
	
	page.css('//a[@class="currency-name-container link-secondary"]').each do |el|	
		array_crypto_name << el.text
   	end
	
	page.css('//a[@class="price"]').each do |el|	#
		array_crypto_price << el.text
   	end

	mon_hash = Hash[array_crypto_name.zip(array_crypto_price)]
	p mon_hash
end

#creat_my_hash
# A noter: obligée de faire un each avant de l'inserer ds tab sinon tab=un block non exploitable
=begin
#########################################################################
# #commande pour lancer le programme toutes les heures
# Indispensable: require 'active_support/time' sinon ne marche pas
last_ran_at = 0
loop do
  run_time = Time.now
  if run_time - last_ran_at >= 10.seconds
    p creat_my_hash
    last_ran_at = run_time
  end
end

=end
############################################################################

# #def get_the_email_of_a_townhal_from_its_webpage
#     doc = Nokogiri::HTML(open("http://www2.assemblee-nationale.fr/elections/liste/2017/resultats/RESULTAT"))
# # Possibilité 1  
#   array_crypto_name = []
#      doc.css('table.tablesorter tr td[2]').each do |el|
#      	array_crypto_name << el.text
#    	end
# p array_crypto_name.size
 
#     def creat_my_hash          
# 	array_crypto_name = []
# 	array_crypto_lastn = []
# 	page = Nokogiri::HTML(open("https://coinmarketcap.com/all/views/all/"))
	
# 	page.css('//a[@class="currency-name-container link-secondary"]').each do |el|	
# 		array_crypto_name << el.text
#    	end
	
# 	page.css('//a[@class="price"]').each do |el|	#
# 		array_crypto_price << el.text
#    	end

# 	mon_hash = Hash[array_crypto_name.zip(array_crypto_price)]
# 	p mon_hash
# end

# #creat_my_hash