# jeudi_1207_scrapping
