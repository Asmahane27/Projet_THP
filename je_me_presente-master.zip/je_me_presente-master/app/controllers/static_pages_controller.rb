class StaticPagesController < ApplicationController
  def home
  end

  def contact
  end

  def about
  end

  def moi
  end

  def mon_groupe	
  end
end
