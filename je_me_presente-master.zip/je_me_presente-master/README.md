# Mon App Je me présente

On a bien galéré, mais on a un lien Heroku!!

Le voici :https://frozen-wildwood-25866.herokuapp.com/

Sinon tu peux downloader le dossier et comme d'hab: 
```bundle install ```
puis lancer la migration : `rails db:migrate` et ouvrir le serveur : `rails server`

Puis dans la barre de recherche aller sur `http://localhost:3000/`

Attention si ça marche pas il faut peut être modifier le gemfile, on en parle au tel!
