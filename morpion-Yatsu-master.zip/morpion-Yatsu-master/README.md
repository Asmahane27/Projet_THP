# Tic-Tac-Toe
A Tic Tac Toe game developped in ruby 

### To make it work
Just run 

```sh
$ ruby game.rb
```

### What it does:
This is a game and there are rules to play it:

* It is a 2 players game, one turn per player
* It asks and registers the name of each player
* The programe displays the board/grid in the terminal
* Of course, there is a winner, and it does tells you when that happens
* But if there are no a winners (it can happen) the program also tells you that.

### What is doesn't do
- Pancakes, sorry but what where you expecting? is a Tic-Tac-Toe game

### Menu
Our game has a menu, in french, we love french, if you don't know it, learn it:

"Bienvenue sur le TicTacToe lyonnais !"
* Tape 1 pour jouer
* Tape 2 pour afficher les règles
* Tape 3 pour afficher les cases
* Tape 4 pour sortir du jeu

### Board Layout

	1 | 2 | 3
    ---------
    4 | 5 | 6
    ---------
    7 | 8 | 9

or something like this, 'cause this is more like and ad of the game, so it has to look nicer.

### The Program
We made many class's (Player, Game, Board, etc).
Each class is in a file.
Each file has many methods
Each method ("ou presque") has many variables
All of this together makes the program work, this is what we call "magic"

[Enjoy the magic !](https://media.giphy.com/media/12NUbkX6p4xOO4/giphy.gif)
