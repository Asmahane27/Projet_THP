class AddColUs < ActiveRecord::Migration[5.2]
  def change
  	add_column :users, :anonymous_gossiper, :string
  end
end
