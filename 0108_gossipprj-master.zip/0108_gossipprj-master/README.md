# The gossip project _ CRUD
