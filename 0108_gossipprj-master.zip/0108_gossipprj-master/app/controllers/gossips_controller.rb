class GossipsController < ApplicationController

def index
@gossips = Gossip.all
end

def create
	@gossip = Gossip.new
	@gossip.title = params[:title]
	@gossip.content = params[:content]
	@gossip.id = params[:id]
	@gossip.save
	redirect_to "/gossips/#{@gossip.id}"
	
end

def new
	 @gossip = Gossip.new
end

def edit 
	#cf show
	# @gossips = Gossip.all
	# @gossips.each do |i|
	# 	i = @gossip
	# end
	#@gossip = @gossip.find(params[:id])
end

def show
	# sur la page =>web error: 
	# undefined method `find' for nil:NilClass
	# sur la console:
	# liste des params:
	# Parameters: {"utf8"=>"✓", 
	# "authenticity_token"=>"jz2DjhR+AuV0+RwFmlbiCezGA2+DeecBFodmBDSNKjyLeTZ69v45Mhxa5MkUQFRo/uX3ryy75xj6U7BJyx+6ZQ==", 
	# "title"=>"adzq", 
	# "content"=>" qadfz"}
	#
	# app/controllers/gossips_controller.rb:22:in `show'
	# Started GET "/gossips/:id" for 127.0.0.1 at 2018-08-02 03:53:36 +0200
	# Processing by GossipsController#show as HTML
	# Parameters: {"id"=>":id"}
	# Completed 500 Internal Server Error in 212ms (ActiveRecord: 0.0ms)
	# NameError (undefined local variable or method `gossip' for #<GossipsController:0x00007fd4105e2ae0>
	# Did you mean?  gossip_url):

  	#@gossip = @gossip.find(params[:id])

 	# sur la page show.html.erb:
 	# <!-- NEMARCHEPAS CF CONTROLLER
	# <p> <%= @gossip.title %> </p>
	# <p><%= @gossip.content %></p>
	# -->
end

def update
	# cf show
	# @gossip = @gossip.find(params[:id])
	# @gossip.title = params[:title]
	# @gossip.content = params[:content]
	# @gossip.title.update
	# @gossip.content.update
	# @gossip.save

	#redirection vers profil mais la flemme ducoup index
	 redirect_to "/gossips"
end

def destroy
	#cf show
	# @gossip = @gossip.find(params[:id])
	# @gossip.destroy
	redirect_to "/gossips"
end
	

	end

	
	
	
	
	
