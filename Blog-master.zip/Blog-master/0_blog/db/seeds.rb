# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
require 'faker'

# 10.times do
#   user = User.create(lastname: Faker::GameOfThrones.house, firstname: Faker::Name.first_name)
# end

# # Article.create( content: "En outre, il a souhaité voir Benoît Hamon lui succéder au poste 
# # 	de la magistrature suprême. « Je suis certain que M. Hamon fera un excellent président »
# # 	 a-t-il commenté en faisant ses bagages. De son côté, Benoît Hamon a estimé qu’il ne serait
# # 	  pas disponible avant mi août « Je suis en vacances avec les enfants on a loué jusqu’à 
# # 	  début août, si on part, on sera pas remboursé et je commence un nouveau taf en septembre, 
# # 	  du coup ça m’arrange pas trop » a répondu l’ancien candidat. M. Macron a ajouté qu’il ne 
# # 	  souhaitait pas que quelqu’un paye à sa place, estimant que son geste était dans la lignée 
# # 	  de la république exemplaire tout en attendant son Uber en bas de l’Élysée. Inquiet du retard 
# # 	  pris par son chauffeur, il a cependant temporisé affirmant que « mon Uber il est inaltérable ».", user_id: 1)
# Article.create(user_id: 2, content: "Benalla possèderait une vidéo dans laquelle Macron se montre favorable à une mesure de gauche")
# Article.create(user_id: 3, content: "Une publicité pour parfum censurée en raison de sa clarté et de sa cohérence")
# Article.create(user_id: 4, content: "Pour attendrir les femmes sur les sites de rencontre, il se faisait passer pour un petit chien")
# Article.create(user_id: 5, content: "« 89 prct es hommes pensent que le clitoris est un modèle de Toyota. » Cette information absurde, présentée comme le résultat d’un sondage par Le Gorafi, a été reprise par l’agence de presse italienne Ansa en septembre 2013, dans une dépêche elle-même publiée par le grand quotidien italien Corriere Della Sera.")
# Article.create(user_id: 6, content: "Reims – c’est une bourde qu’Anis n’est pas près de refaire de sitôt. Tandis qu’il faisait la queue à la supérette de proximité, le jeune homme de 34 ans a salué la caissière alors qu’elle n’avait pas fini d’encaisser le précédent client.")
# Article.create(user_id: 7, content: "Affaire Benalla – Les policiers inquiets que cela jette le discrédit sur les policiers qui frappent vraiment les manifestants")
# Article.create(user_id: 8, content: "Un article qui aurait été écrit de manière totalement inutile et gratuite dans le but d’attirer un lectorat nocturne avide de sensations fortes et espérant du nouveau. « Il s’agit d’un plan purement marketing, qui force le lecteur à cliquer un lien pour espérer des retombées publicitaires » a commenté de son côté une journaliste du Parisien qui espérait des révélations croustillantes pour son édition du matin, dégoûtée de réaliser que son clic et ceux de milliers d’autres internautes allaient juste contribuer à remplir nos caisses pour la construction de notre second yacht.")
# Article.create(user_id: 9, content: "hocus-focus : Suivant les pas de Facebook, le réseau social Twitter va aussi lancer dans les mois qui viennent son propre service de rencontres, réservé dans un premier temps aux haters. Pour que la haine mène à l’amour ?")
# Article.create(user_id: 10, content: "France : la recherche sur l'intelligence artificielle aboutit à un nouveau porte-clés lumineux")
10.times do	
Article.create(title: Faker::StarWars.wookiee_sentence)
end

#############################################
# u = User.find(2)
# a = Article.new
# a.user = u
# u.save
# u = User.find(3)
# a = Article.new
# a.user = u
# # u.save
#########################################################################""

# Category.create(name: "test1")
# Category.create(name: "test2",article_id: 2)
# Faker::Color.color_name #=> "yellow"

# 10.times do
#  t = Category.create(article_id:Faker::Number.between(1, 11), name: Faker::Color.color_name)
# end