require 'test_helper'

class ThearticleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
