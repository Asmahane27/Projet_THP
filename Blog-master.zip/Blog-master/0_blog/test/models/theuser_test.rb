require 'test_helper'

class TheuserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
