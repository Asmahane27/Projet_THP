class StaticController < ApplicationController
  def home
  end
end
