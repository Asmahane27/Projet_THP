class UsersController < ApplicationController
  
  def newuser
  end

  def create
  	# u = User.new
  	# u.user = params["username"]
  	# u.save
  	# p params.inspect
  	# redirect_to "/static/home"

  	@user = User.new

    @user.user = params["username"]

    @user.bio = params["bio"]

    @user.save
    
    redirect_to "/show/#{@user.id}"

  end

  def show
	@user.user = params["username"]

    @user.bio = params["bio"]
  end
  
end
