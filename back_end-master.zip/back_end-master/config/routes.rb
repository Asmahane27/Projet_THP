Rails.application.routes.draw do
  root  to: 'static#home'
  
  get '/static/home', to: 'static#home', as: 'static_home'
  get '/users/newuser', to: 'users#newuser', as: 'users_newuser'
  post '/' , to: 'users#create', as: 'users_create'
    
  get 'show/:id', to:'users#show'
end
# For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html