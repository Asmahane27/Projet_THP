Exo journalist.rb et crypto.rb

Fait par GINO et WILLIAM