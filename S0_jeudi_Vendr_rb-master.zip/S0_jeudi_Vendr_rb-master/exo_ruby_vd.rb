#########################################################################################
=begin
puts "

exo_10

"
#Écris un programme exo_10.rb qui demande l'année de naissance à l'utilisateur, 
#et qui va ressortir l'age que l'utilisateur a eu en 2017. 


puts "Bonjour, c'est quoi ton année de naissance?"
ann_naiss = gets.chomp.to_i
puts "Donc en 2017 tu avais #{2017-ann_naiss.to_i} ans!"



#########################################################################################
puts "

exo_11

"
#Écris un programme exo_11.rb qui demande un nombre à l'utilisateur, 
#puis qui écrira autant de fois "Salut, ça farte ?"
puts "Ecris ton nombre préféré (essaye d'avoir des préférences comprises entre 0 et 10)"
i=gets.chomp.to_i
i.times do 
	puts "Salut, ça farte ?"
	end



#########################################################################################
puts "

exo_12

"
#Écris un programme exo_12.rb qui demande un nombre à l'utilisateur, 
#puis qui comptera jusqu'à ce nombre.
i=0
puts "Ecris ton nombre préféré :"
print "> "
ton_nb=gets.chomp.to_i

ton_nb.times do |i|
	
	puts i=i+1
	end



#########################################################################################
puts "

exo_13

"
#Écris un programme exo_13.rb qui demande l'année de naissance d'un utilisateur, 
#et qui va ressortir chaque année depuis son année de naissance jusqu'à 2018.

puts "Bonjour, quelle est ton année de naissance?"
print "> "
ann_naiss = gets.chomp.to_i

age=(2018-ann_naiss)

if ann_naiss<2018
	age.times do
		puts ann_naiss+=1
	end
end



#########################################################################################
puts "

exo_14

"
#Écris un programme exo_14.rb qui demande un nombre à l'utilisateur, 
#puis qui affiche un compte à rebours à partir de ce nombre, jusqu'à 0.
puts "Ecris ton nombre préféré :"
print "> "
ton_nb = gets.chomp.to_i


ton_nb.times do 
	
	puts ton_nb = ton_nb-1
	end




#########################################################################################


puts "

exo_15

"
#Écris un programme exo_15.rb qui demande l'année de naissance d'un utilisateur et qui 
#va afficher chaque année depuis son année de naissance jusqu'en 2017. 
#Pour chaque année affichée, le programme devra annoncer l'age que l'utilisateur 
#a eu cette année.

puts "Bonjour, quelle est ton année de naissance?"
print "> "
ann_naiss = gets.chomp.to_i

age=(2017-ann_naiss)

#if ann_naiss<2017
	age_result = 0
	age.times do
		
			puts "En #{result = (ann_naiss+=1)} tu avais #{age_result += 1 } ans!"
	end
#end



#########################################################################################


puts "

exo_16

"

#Le programme exo_15.rb est cool, mais on peut l'améliorer. Écris un programme exo_16.rb 
#qui va demander l'age de l'utilisateur, et qui, pour chaque âge, dira "Il y a X ans,
# tu avais Y ans".

puts "Bonjour, quelle est ton age?"
print "> "
age = gets.chomp.to_i

age_result = 0


age.times do
	puts "Il y a #{age-=1} ans tu avais #{age_result+=1} ans"

end




#########################################################################################

#PAS BON A REFAIRE
puts "

exo_17

"
#Notre programme exo_16.rb est devenu beau gosse. Écris un programme exo_17.rb 
#qui va faire la même chose, sauf que si X et Y sont égaux, il dira "Il y a n ans, 
#tu avais la moitié de l'age que tu as aujourd'hui".

puts "Bonjour, quelle est ton age?"
print "> "
age = gets.chomp.to_i

age_result = 0

i = age.truncate 
age.times d=endo |i|
	if i != (age/2).floor 

		puts "Il y a #{i = (age-=1)} ans tu avais #{age_result+=1} ans"
	else 
		puts "Il y a #{i= (age-=1) } ans tu avais la moitié de ton age"
	end
end




#########################################################################################
###NE MARCHE PAS
puts "

exo_18

"
#Écris un programme exo_18.rb qui va créer une liste de 50 faux emails et les stocker
# dans une array. 
#Voici le format que devront avoir les faux emails :

#"jean.dupont.01@email.fr"
#"jean.dupont.02@email.fr"
#etc..

#test1==>
#nom ="jean.dupont."
#i = 0
#suff = "@email.fr"

#10.times do
#nom + (i+=1) + suff
#end

#test 2==>
#i=0
#tab = ["jean.dupont.", i, "@email.fr"]
#array.new(4) = tab

#test 3
#tab = ["jean.dupont.", 1,"@email.fr"]
#tab = Array.new (10)
#puts tab

#test 4
#tab = ["jean.dupont.", i, "@email.fr"]
#adr_mail_fake = ["fich_client_fake"]
#i=0
#adr_mail_fake.each do 

#	puts "jean.dupont."(i = i+1)"@email.fr"
#end

#adr_mail_fake =Array.new(10)
#puts adr_mail_fake

#test 5
#10.times do |i| 
#puts "jean.dupont.#{i}@email.fr"
#end
=begin
#########################################################################################

puts "

exo_19

"

#Prends le programme exo_18.rb et créé un programme exo_19.rb qui va reprendre l'array 
#des emails créés, et n'afficher que les emails avec un nombre pair.

"jean.dupont.02@email.fr"
"jean.dupont.04@email.fr"
etc..


#########################################################################################

puts "

exo_20

"
#Construis un programme exo_20.rb qui va demander à l'utilisateur un nombre entre 1 et 25 
#et qui va sortir une pyramide à descendre de tant d'étages que ce nombre. Voici un exemple :

#Salut, bienvenue dans ma super pyramide ! Combien d'étages veux-tu ?
#> 5
#Voici la pyramide :
#
##
###
####
#####


puts "Ecris un nombre en 1 et 25 :"
print "> "
ton_nb=gets.chomp.to_i

#ton_nb.times do |i|
	x=1
	ton_nb.times do
		x.times do 
			print "#"

end 
# Fin du loop

puts "" 
# Retour à la ligne

x+=1
end 
	#i=i+1
	#i.times do
	#	puts "#"
	#end
	#end

=end
#########################################################################################

puts "

exo_21

"

#Reprends ton programme exo_20.rb et fais un programme pyramide.rb qui montera 
#au lieu de descendre :

#Salut, bienvenue dans ma super pyramide ! Combien d'étages veux-tu ?
#> 5
#Voici la pyramide :
    #
   ##
  ###
 ####
#####

#Bien que légèrement différent dans l'énoncé, ce programme est bien plus dur que le exo_20.rb, 
#donc c'est normal de devoir réfléchir à comment le faire 😎

puts "Ecris un nombre en 1 et 25 :"
print "> "
ton_nb=gets.chomp.to_i

#ton_nb.times do |i|
	x=ton_nb
	ton_nb.times do
		x.times do 
			print "#"

end 


puts "" 


x-=1
end 
	

