=begin
Créé un programme exo_01.rb 
qui affichera affiche "Bonjour, monde !". 
Voici les lignes qu'il doit avoir d'affichées 
lorsque tu l'exécutes :
$ ruby exo_01.rb
Bonjour, monde !
=end
puts "

exo_01
 
 "
	exo_01 ="Bonjour, monde !"
	puts exo_01

=begin
Créé un programme exo_02.rb qui affiche les lignes suivantes :
$ ruby exo_02.rb
Bonjour, monde !
Et avec une voix sexy, ça donne : Bonjour, monde !
En faisant une recherche Google, 
peux-tu connaître la différence entre print et puts ? 
=end
puts "

exo_02

 "
	exo_02 = "Et avec une voix sexy, ça donne : Bonjour, monde !"

	puts exo_01, exo_02
#Chaque varible à la ligne

	print exo_01, exo_02
#Toutes les var sur la même ligne

=begin Reprends ton programme exo_02.rb, 
puis écris un programme exo_03.rb qui est le même, 
mais avec # devant la ligne 2. Peux-tu me dire ce qu'il se passe ? 
=end

puts "

exo_03

"
	exo_3 = "Et avec une voix sexy, ça donne : Bonjour, monde !"

	puts exo_01, exo_02

	#Rép: Hastag pour les commentaires sur une ligne, la commande n'est pas dans le run
=begin 
Créé un programme exo_04.rb avec les lignes suivantes :
puts "Salut, ça farte ?
Lance le programme. Que se passe-t-il ? Pourquoi ?
=end
puts "

exo_04

"
puts "Salut, ça farte ? "
=begin 
là j'ai rajouté le dernier guillet pour laisser mon comm, mais sinon, la console affiche :
"unterminated string meets end of file" = erreur les guillets ne sont pas fermés
=end

=begin
Écris un programme exo_05.rb avec les lignes suivantes :
#lignes en dessous#	
D'abord, que fait #{} ? 
Ensuite, mets un commentaire devant chacune des lignes et explique ce qu'elle fait.
=end

puts "

exo_05

"
puts "On va compter le nombre d'heures de travail à THP" #Affiche la phrase sur la console
puts "Travail : #{10 * 5 * 11}" #Concatenation au sein d'une phrase (#{}), ici les crochets contiennent une opération dont le résultat apparait sur la console
puts "En minutes ça fait : #{10 * 5 * 11 * 60}"#idem ci dessus

puts "Et en secondes ?"

puts 10 * 5 * 11 * 60 * 60 #le résultat du calcul apparait sur la console

puts "Est-ce que c'est vrai que 3 + 2 < 5 - 7 ?"# affiche la phrase

puts 3 + 2 < 5 - 7# c'est un booleen, ainsi rédigé, la console ne renseigne que la réponse soit true ou false, ici = false

puts "Ça fait combien 3 + 2 ? #{3 + 2}"# déjà expliqué cf concat + booleen
puts "Ça fait combien 5 - 7 ? #{5 - 7}"# déjà expliqué

puts "Ok, c'est faux alors !"# déjà expliqué

puts "C'est drôle ça, faisons-en plus :"# déjà expliqué

puts "Est-ce que 5 est plus grand que -2 ? #{5 > -2}"# déjà expliqué
puts "Est-ce que 5 est supérieur ou égal à -2 ? #{5 >= -2}"# déjà expliqué
puts "Est-ce que 5 est inférieur ou égal à -2 ? #{5 <= -2}"# déjà expliqué

=begin
Écris un programme exo_06.rb avec les lignes suivantes :
Lance-le programme, et essaie de le comprendre. 
=end
puts "

exo_06

"
number_of_hours_worked_per_day = 10
number_of_days_worked_per_week = 5
number_of_weeks_in_THP = 11

puts "Travail : #{number_of_hours_worked_per_day * number_of_days_worked_per_week * number_of_weeks_in_THP}"
#Ajoute après la ligne suivante, Que se passe-t-il ? Peux-tu expliquer ?
#puts "Et en minutes ça fait : #{number_of_minutes_in_an_hour * number_of_hours_worked_per_day * number_of_days_worked_per_week * number_of_weeks_in_THP}"
#La variable number_of_minutes_in_an_hour n'a pas été déclarée...aucun résultat ne peut être délivré.

puts '

exo_07_a

'
=begin 
Écris un programme exo_07_a.rb avec les lignes suivantes :
Peux-tu me dire ce que fais gets.chomp ?
=end
puts "Bonjour, c'est quoi ton blase ?"
user_name = gets.chomp
puts user_name
#trop cool! ca permet d'editer directement sur la console pour définir user_name

puts '

exo_07_b

'
=begin
Après, écris un programme exo_07_b.rb avec les lignes suivantes :
=end
puts "Bonjour, c'est quoi ton blase ?"
print "> "
user_name = gets.chomp
puts user_name


puts '

exo_07_c

'
=begin
Enfin, écris un programme exo_07_c.rb avec les lignes suivantes :
Quelles sont les différences entre les trois programmes ?
=end
user_name = gets.chomp
puts user_name
#celui qui a rédigé exo_07_a et b est plus poli...Sinon c'est à peu près pareil!
#le print du b est utile pour mettre en avant sur la console ce qui a été renseigné par l'utilisateur; 

puts "

exo_08

"
#Écris un programme exo_08.rb qui demande le prénom de l'utilisateur, et qui salue l'utilisateur avec "Bonjour, prénom !"
puts "Quel est ton prénom?"
print "> "
user_name = gets.chomp
puts "Bonjour #{user_name}"


puts "

exo_09

"
=begin
Écris un programme exo_09.rb qui demande le prénom de l'utilisateur, 
qui lui demande après son nom de famille, et qui salue l'utilisateur avec "Bonjour, prénom nom !"
=end
puts "Quel est ton prénom?"
print "> "
user_name = (gets.chomp )
puts "Quel est ton nom?"
print "> "
user_last_name = gets.chomp
puts "Bonjour #{user_name +" "+ user_last_name}"
