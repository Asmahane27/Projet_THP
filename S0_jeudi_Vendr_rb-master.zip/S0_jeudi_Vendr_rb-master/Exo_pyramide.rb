puts "

exo_20

"
#Construis un programme exo_20.rb qui va demander à l'utilisateur un nombre entre 1 et 25 
#et qui va sortir une pyramide à descendre de tant d'étages que ce nombre. Voici un exemple :

#Salut, bienvenue dans ma super pyramide ! Combien d'étages veux-tu ?
#> 5
#Voici la pyramide :
#
##
###
####
#####


puts "Ecris un nombre en 1 et 25 :"
print "> "
ton_nb=gets.chomp.to_i


	x=1
	ton_nb.times do
		x.times do 
			print "#"

end 


puts "" 


x+=1
end 
	
#########################################################################################
#########################################################################################

puts "

exo_21

"

#Reprends ton programme exo_20.rb et fais un programme pyramide.rb qui montera 
#au lieu de descendre :

#Salut, bienvenue dans ma super pyramide ! Combien d'étages veux-tu ?
#> 5
#Voici la pyramide :
    #
   ##
  ###
 ####
#####

#Bien que légèrement différent dans l'énoncé, ce programme est bien plus dur que le exo_20.rb, 
#donc c'est normal de devoir réfléchir à comment le faire 😎

puts "Ecris un nombre en 1 et 25 :"
print "> "
ton_nb=gets.chomp.to_i


	x=ton_nb
	ton_nb.times do
		x.times do 
			print "#"

end 


puts "" 


x-=1
end 
	