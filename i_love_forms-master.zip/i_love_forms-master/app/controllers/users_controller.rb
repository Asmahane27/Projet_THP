class UsersController < ApplicationController
  
  def home
  end

  # def new
  #   @user = User.new
  # end

  def ftag
  end

  def ffor
  end

  def create
  	
  	@user = User.new
    @user.username = params["username"]
    @user.email = params["email"]
    @user.bio = params["bio"]
    @user.save
    
    redirect_to "/ayetexistes/#{@user.id}"

  end

 

 def ayetexistes
user = User.find(params[:id])
@p = user.username

  end
end
