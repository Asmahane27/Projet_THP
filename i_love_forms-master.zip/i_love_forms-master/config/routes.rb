Rails.application.routes.draw do
  root to: 'users#home'
  get 'users/new', to:'users#new', as: 'formulaireHTML'
  get 'users/ftag', to:'users#ftag', as: 'formulaireFTAG'
  get 'users/ffor', to:'users#ffor', as: 'formulaireFFOR'
  get 'ayetexistes/:id', to:'users#ayetexistes', as: 'fin'
  
  post '/' , to: 'users#create', as: 'users_create'
  post 'createftag' , to: 'users#createftag', as: 'users_createfftag'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end

