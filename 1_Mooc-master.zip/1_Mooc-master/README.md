# README

# Application Hacking Class
Salut moussaillon tu vas bien?

Dans ce README il y a un exo d'une app rails de Hacking Class, avec des cours et des élèves.

# Lancer l'appli
Télécharge ou clone le repo

Place toi dans le dossier correspondant et fait depuis ton terminal bundle install

Puis dans le dossier db ouvre le fichier sqlite pour voir les bases de données.

Bon appétit!

# Contenu
### Les cours
Il y'a différents types de cours, avec des titres & des descriptions.

### Les élèves
Il y'a différents élèves mais chaque élèves ne peut être inscrit qu'à un seul cours.

Bon THP à toi moussaillon!
