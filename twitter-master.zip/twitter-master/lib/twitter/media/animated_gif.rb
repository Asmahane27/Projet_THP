require 'twitter/media/video'

module Twitter
  module Media
    class AnimatedGif < Video
    end
  end
end
