module Twitter
  module Streaming
    class FriendList < Array
    end
  end
end
