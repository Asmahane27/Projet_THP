# frozen_string_literal: true

module MeTooHelper
  def me() "me too!" end
end
