# frozen_string_literal: true

module AbcHelper
  def bare_a() end
end
