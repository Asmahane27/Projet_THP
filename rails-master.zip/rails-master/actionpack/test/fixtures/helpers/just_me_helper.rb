# frozen_string_literal: true

module JustMeHelper
  def me() "mine!" end
end
