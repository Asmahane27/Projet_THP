# write your code here
#CODE DE M***
#def who_is_bigger (i,j,k)
 #   tab = [i,j,k]
  #tab.each do |x|
   # if x == nil 
   # p "nil detected"
    #elsif x == tab.max && tab[0]
    #p "a is bigger"    
    #elsif x == tab.max && tab[1]
    #p "b is bigger"
    #elsif x == tab.max && tab[2]
    #p "c is bigger"    
    #end
    #end
#end



def reverse_upcase_noLTA (word)
word_reverse = word.reverse
word_upc = word_reverse.upcase
word_lta = word_upc.delete('LTA')
p word_lta
end

def array_42 (tab)
tab.include?(42)
end


def magic_array (tab)
tab_fl_s = tab.flatten.sort
tab_m = tab_fl_s.collect { |n| n * 2 }
tab_d = tab_m.delete_if {|n| n%3 == 0 } 
tab_u = tab_d.uniq
p tab_u
end




