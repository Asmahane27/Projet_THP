#write your code here
def time_string (nb)
nb_form = Time.at(nb).utc.strftime("%H:%M:%S")
p nb_form
end

