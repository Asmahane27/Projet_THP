if x == nil 
	p "nil detected"
if mhash.has_value?(nil)
        p "nil detected"

who_is_bigger(82,55,nil)

def who_is_bigger (i,j,k)
	tab = [i,j,k]
tab.each do |x|
	if x == nil 
	p "nil detected"
	elsif x == tab.max && tab[0]
	p "a is bigger"	
	elsif x == tab.max && tab[1]
	p "b is bigger"
	elsif x == tab.max && tab[2]
	p "c is bigger"	
	end
	end
end
end

def who_is_bigger(i,j,k)
	each do |x|
	if x == nil
		p "nil detected"
		if i.to_i > j.to_i or i.to_i > k.to_i
	p "a is bigger"	
	elsif j.to_i == j.to_i > i.to_i or j.to_i > k.to_i
	p "b is bigger"
	else k.to_i == k.to_i > j.to_i or k.to_i > i.to_i
	p "c is bigger"	
	end
	end
	end
	end
	end
end



def who_is_bigger(i,j,k)
	if i == nil
	p "nil detected"
	elsif j == nil
	p "nil detected"
	else k == nil
	p "nil detected"
	end
	
end

#last tentative
def who_is_bigger(i,j,k)
	tab = [i,j,k] 
	if has_value(tab, nil) then
	p "nil detected"
  	else 
	tab.each do |x|
	if x.to_i == tab.max && tab[0]
	p "a is bigger"	
	elsif x.to_i == tab.max && tab[1]
	p "b is bigger"
	elsif x.to_i == tab.max && tab[2]
	p "c is bigger"	
	end
	
end