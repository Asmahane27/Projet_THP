#write your code here


def ftoc(f)
  c = (f.to_i - 32) * 5.0 / 9.0
  p c.round
end

def ctof(c)
  f = (c.to_f * 9.0 / 5.0) + 32
  p f
end

#test=37
#ctof (test)