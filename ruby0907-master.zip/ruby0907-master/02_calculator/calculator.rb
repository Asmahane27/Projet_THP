#write your code here
def add (i,j)
	p result = i.to_i + j.to_i
end

def subtract (i,j)
	p result = i.to_i - j.to_i
end

def sum (tab)
	if tab.length < 1
		then p result = 0
	else
	p result = (tab).sum
end
end

def multiply (i,j)
	p result = i.to_i * j.to_i
end