def hello
p "Hello!"
end

def greet(name)
p "Hello, #{name}!"
end