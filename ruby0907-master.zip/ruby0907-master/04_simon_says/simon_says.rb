#write your code here
def echo (word)
p word
end

def shout (word)
p word.upcase
end

def repeat (word, i=2)
	p "#{word.to_s} " * (i-1) + "#{word.to_s}"
	end

def start_of_word (world, i)
	world2 = "#{world[0..i-1]}"
	p world2
end

def first_word (word)
	word2 = word.split (" ")
	p word2[0]
end

#manque le dernier#LARAGE!
def titleize(phrase)
 no_cap = ["and" ]
  phrase2 = phrase.split(" ").map { |word| no_cap.include?(word) ? word : 
  word.capitalize }.join(" ")
  p phrase2
end




