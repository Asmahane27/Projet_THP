require 'test_helper'

class CommentaireTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
